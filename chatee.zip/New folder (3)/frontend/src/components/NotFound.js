import React from 'react';


// Functional Component
const NotFound = () => {
  return (
    <div class="flex h-[86vh] text-[#ffffff] bg-[#272727] items-center justify-center">
        <p class="text-[60px]">
            404 ERROR
        </p>
    </div>

  );
};

export default NotFound;